strH = 'I:\Experiments\Paper_3\data3\V_Hig\';  
strM= 'I:\Experiments\Paper_3\data3\V_Mid\';
str1 = 'I:\Experiments\Paper_3\data3\Low\';
str3 = '.png';

for ii = 119:200
    close all;
    str2=int2str(ii);
    dirName = [str1,str2,str3];
    tmp=imread(dirName);
    I_1=tmp;
    tmp=double(tmp);
    y1=crf(tmp,16);
    y2=crf(tmp,4);
    %generate
    I1=tmp;
    I2=uint8(y1);
    I3=uint8(y2);
    I2=double(I2);
    I3=double(I3);
    %%�õ�����ͼƬ����ʽ1��2��3��4��5��
    make=maker;
    %%WGIF����,I1e��ʾdetail layer, I1base��ʾbase layer
    [I1e,I1base]  =  WGIF2(tmp);
    r21  =  make.r2(I1,I1e,I1base,I2);
    r22  =  make.r2(I1,I1e,I1base,I3);
    r21  =  repmat(r21,[1 1 3]);
    r22  =  repmat(r22,[1 1 3]);
    % 
    w_low_high  =  r21.*(I1base) + I1e;
    w_low_midle =  r22.*(I1base) + I1e;
    %case one and case two
    [mtmpa,mtmpb] = change(I1);
    wr_low_high   = I2 .* mtmpa + w_low_high  .* mtmpb;
    wr_low_midle  = I3 .* mtmpa + w_low_midle .* mtmpb;

    wr_low_high   = uint8(wr_low_high); 
    wr_low_midle  = uint8(wr_low_midle);
    
    dirNameH   = [strH,str2,str3];
    dirNameM   = [strM,str2,str3];
    imwrite(wr_low_high,dirNameH);
    imwrite(wr_low_midle, dirNameM);
    
end