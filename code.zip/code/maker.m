function funs = maker
    funs.r1=@r1;
    funs.r2= @r2;
end

function r1=r1(z1,zi)
    z1=double(z1);
    zi=double(zi);
    z1r=z1(:,:,1);   z1g=z1(:,:,2);    z1b=z1(:,:,3);
    zir=zi(:,:,1);   zig=zi(:,:,2);    zib=zi(:,:,3);

    %  zir(z1r<10)=zir(z1r<10)+8; zig(z1g<10)=zig(z1g<10)+8; zib(z1b<10)=zib(z1b<10)+8;
    w_z1r=w560(z1r);   w_z1g=w560(z1g);    w_z1b=w560(z1b);
    % z1r(z1r<10)=z1r(z1r<10)+8; z1g(z1g<10)=z1g(z1g<10)+8; z1b(z1b<10)=z1b(z1b<10)+8;

    %z1��ziͬΪ0�ĵط���1
    % z1r(z1r==0)=1;z1g(z1g==0)=1;z1b(z1b==0)=1;
    %  zir(zir==0)=1;zig(zig==0)=1;zib(zib==0)=1;
    % w_z1r(w_z1r==0)=1;w_z1g(w_z1g==0)=1;w_z1b(w_z1b==0)=1;

    r1_a = w_z1r.*z1r.*zir + w_z1g.*z1g.*zig + w_z1b.*z1b.*zib;
    r1_b = w_z1r.*z1r.*z1r + w_z1g.*z1g.*z1g + w_z1b.*z1b.*z1b;
    r1   = r1_a./r1_b;

    % r1=(w_z1r.*z1r.*zir+w_z1g.*z1g.*zig+w_z1b.*z1b.*zib)./(w_z1r.*z1r.*z1r+w_z1g.*z1g.*z1g+w_z1b.*z1b.*z1b);
     r1(isnan(r1))=1;
    % I1=double(I1);I2=double(I2);
    % I1_YUV=rgb2ycbcr(I1);I1_Y=I1_YUV(:,:,1);
    % I2_YUV=rgb2ycbcr(I2);I2_Y=I2_YUV(:,:,1);
    % r1=double(I2_Y)./double(I1_Y);
end

% z1  : low image
% z1e : structure of low image
% z1bs: detail of low image
% zi  : CRF function of low image
function r2 = r2(z1ow,z1e,z1bs,zcrf)
    z1ow  =  double(z1ow);
    zcrf  =  double(zcrf);
    z1e   =  double(z1e);
    z1bs  =  double(z1bs);

    z1owr = z1ow(:,:,1);          z1owg = z1ow(:,:,2);            z1owb =  z1ow(:,:,3); % ��ʵ�ĵ��ն�ͼ��
    z1ow_struct_r  = z1e(:,:,1);  z1ow_struct_g = z1e(:,:,2);     z1ow_struct_b  =  z1e(:,:,3);  %ͼ��ĵ�Ƶ����
    z1ow_detail_r = z1bs(:,:,1);  z1ow_detail_g = z1bs(:,:,2);    z1ow_detail_b =  z1bs(:,:,3);  %ͼ��ĸ�Ƶ����
    z_crf_r = zcrf(:,:,1);        z_crf_g = zcrf(:,:,2);          z_crf_b =  zcrf(:,:,3);        %CRF�����������ͼ��

    % z1bsr(z1r<10)=z1bsr(z1r<10)+8; z1bsg(z1g<10)=z1bsg(z1g<10)+8; z1bsb(z1b<10)=z1bsb(z1b<10)+8;
    % % z1er(z1r<10)=z1er(z1r<10)+8;z1eg(z1g<10)=z1eg(z1g<10)+8; z1eb(z1b<10)=z1eb(z1b<10)+8;
    %  zir(z1r<10)=zir(z1r<10)+8; zig(z1g<10)=zig(z1g<10)+8; zib(z1b<10)=zib(z1b<10)+8;
    w_z1r = w560(z1owr);      w_z1g = w560(z1owg);       w_z1b = w560(z1owb);    % Ȩֵ�ļ���
    % z1r(z1r<10)=z1r(z1r<10)+8; z1g(z1g<10)=z1g(z1g<10)+8; z1b(z1b<10)=z1b(z1b<10)+8;

    % w_z1r=w(z1r);w_z1g=w(z1g);w_z1b=w(z1b);
    % zir(zir==0)=1;zig(zig==0)=1;zib(zib==0)=1;
    % z1er(z1er==0)=1;z1eg(z1eg==0)=1;z1eb(z1eb==0)=1;
    % z1bsr(z1bsr==0)=1;z1bsg(z1bsg==0)=1;z1bsb(z1bsb==0)=1;

    r2_a = w_z1r.*z1ow_detail_r.*(z_crf_r-z1ow_struct_r) + w_z1g.*z1ow_detail_g.*(z_crf_g-z1ow_struct_g) + w_z1b.*z1ow_detail_b.*(z_crf_b-z1ow_struct_b);
    r2_b = w_z1r.*z1ow_detail_r.*z1ow_detail_r  +  w_z1g.*z1ow_detail_g.*z1ow_detail_g  +  w_z1b.*z1ow_detail_b.*z1ow_detail_b;
    r2=r2_a./r2_b;
end






