clear all;
close all
clc
%%test boxfilter
a=[1 2 3 4 1; 5 6 7 8 1; 1 2 3 1 1;1 2 3 4 1];
b=boxfilter(a,1);
