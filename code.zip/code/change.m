

function [mtmpa,mtmpb]=change(I1)  
    mtmp1=I1(:,:,1);
    mtmp2=I1(:,:,2);
    mtmp3=I1(:,:,3);    
    mtmp1(  0<=mtmp1 & mtmp1 < 5 ) = 0;   mtmp1( mtmp1 >=5 ) = 1;
    mtmp2(  0<=mtmp2 & mtmp2 < 5 ) = 0;   mtmp2( mtmp2 >=5 ) = 1;
    mtmp3(  0<=mtmp3 & mtmp3 < 5 ) = 0;   mtmp3( mtmp3 >=5 ) = 1;

    mtmp11 = I1(:,:,1);
    mtmp21 = I1(:,:,2);
    mtmp31 = I1(:,:,3);
    mtmp11( 0 <= mtmp11 & mtmp11 <5 ) = 1;  mtmp11( mtmp11 >= 5) =0;
    mtmp21( 0 <= mtmp21 & mtmp21 <5 ) = 1;  mtmp21( mtmp21 >= 5) =0;
    mtmp31( 0 <= mtmp31 & mtmp31 <5 ) = 1;  mtmp31( mtmp31 >= 5) =0;

    mtmpa(:,:,1) = mtmp1;   mtmpa(:,:,2) = mtmp2;  mtmpa(:,:,3) = mtmp3;
    mtmpb(:,:,1) = mtmp11;  mtmpb(:,:,2) = mtmp21; mtmpb(:,:,3) = mtmp31;
end