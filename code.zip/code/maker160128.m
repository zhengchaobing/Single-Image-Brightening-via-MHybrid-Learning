function funs = maker160128

funs.w11=@w11;

funs.w22= @w22;

end

function w=w11(mtmp)
        mtmpY = 0.299*mtmp(:,:,1)+0.587*mtmp(:,:,2,:)+0.114*mtmp(:,:,3,:);
        Y=mtmpY;
        % 
         Y(mtmpY>160)=2;
         Y(mtmpY<=160  &  mtmpY>128)=1+1.*(  h( Y(mtmpY<=160&mtmpY>128) )   ).^2.*(3-2.*h((Y(mtmpY<=160&mtmpY>128))));
         Y(mtmpY<=128)=1;
        % 
        % Y(mtmpY>96)=4;
        % Y(mtmpY<=96&mtmpY>88)=1+3.*(h(Y(mtmpY<=96&mtmpY>88))).^2.*(3-2.*h((Y(mtmpY<=96&mtmpY>88))));
        % Y(mtmpY<=88)=exp(-((Y(mtmpY<=88)-88).^2)./(2.*36.*36));

        % Y(mtmpY>196)=4;
        % Y(mtmpY<=196&mtmpY>188)=1+3.*(h(Y(mtmpY<=196&mtmpY>188))).^2.*(3-2.*h((Y(mtmpY<=196&mtmpY>188))));
        % Y(mtmpY<=188)=exp(-((Y(mtmpY<=188)-128).^2)./(2.*32.*32));
        w=Y;
end

function h=h(z)
        h=(z-128)./32;
end

function w=w22(mtmp)
        mtmpY= 0.299*mtmp(:,:,1)+0.587*mtmp(:,:,2,:)+0.114*mtmp(:,:,3,:);
        Y=mtmpY;
        % w=exp(-((Y-88).^2)./(2.*36.*36));
         w=exp((-((Y-128).^2))./(2.*52.*52));
end