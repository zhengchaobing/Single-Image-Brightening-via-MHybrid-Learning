% example: detail enhancement
% figure 6 in our paper
function [e,q]=WGIF2(I)


tic

r = 21;
eps = 1/2;

[height,width,color]=size(I);

% Y=rgb2ycbcr(I);
%  Y=double(Y);
% I=double(I);
 Y = 0.299*I(:,:,1)+0.587*I(:,:,2)+0.114*I(:,:,3);
%%%Compute the weights for the WGIF
inY = zeros(height,width);
% inY=rgb2gray(I);
q = zeros(height,width,3);
e = zeros(height,width,3);
for ii=1:height
     for jj=1:width
         inY(ii,jj) = (77*I(ii,jj,1)+150*I(ii,jj,2)+29*I(ii,jj,3)+128)/256;
     end
end
%  figure(3),imshow(inY,[]);
 [C] = CalculateWeightingFactor_PixBased(inY(:,:)); 
 h = fspecial('gaussian',[8,8], 15); 
 C = imfilter(C,h,'same');


%%%Decompose each color channel into two layers using the WGIF
%%%The Y component is selected as the guidance image because it is less
%%%noisy
for ii=1:3
    q(:, :, ii) = Weight_Guided_Filter(Y(:, :), I(:, :, ii), r, eps, C);
    e(:,:,ii) = I(:,:,ii)-q(:,:,ii);            
end    
t = toc

% figure(1),imshow(q./255);
% figure(2),imshow(e);
% imwrite(q./255,'Underwater_Base_Layer_WGIF.png','png');
% imwrite(e,'Underwater_Detail_Layer_WGIF.png','png');



