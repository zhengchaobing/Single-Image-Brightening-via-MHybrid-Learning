function R = exposure_fusion(I,m,method)
%method = 2; 
BETA = 2; %%%test four different choices of BETA as 0, 1, 2, 3
I1=I;    
r  = size(I,1);
c  = size(I,2);
N = size(I,4);

nlev = floor(log(min(r,c)) / log(2))-BETA;
radius = 2^BETA; %60
eps = 1/1024;  %1/2048  8196 32768

% compute the measures and combines them into a weight map
contrast_parm = m(1);
sat_parm = m(2);
wexp_parm = m(3);
makerw=maker160128;
% W(:,:,1)=makerw.w11(I(:,:,:,1)).*makerw.w22(I(:,:,:,1));
% W(:,:,2)=makerw.w22(I(:,:,:,2));
% W(:,:,3)=makerw.w22(I(:,:,:,3));

 W1 = ones(r,c,N);
% W1 = ones(r,c);
if (contrast_parm > 0)
    W1 = W1.*contrast(I1).^contrast_parm;
end
if (sat_parm > 0)
    W1 = W1.*saturation(I1).^sat_parm;
end
if (wexp_parm > 0)
    W1 = W1.*well_exposedness(I1).^wexp_parm;
end

% W(:,:,1)=W1.*makerw.w11(I(:,:,:,1)).*contrast(I(:,:,:,1)).*saturation(I(:,:,:,1)).*well_exposedness(I(:,:,:,1));
% W(:,:,2)=W1.*contrast(I(:,:,:,2)).*saturation(I(:,:,:,2)).*well_exposedness(I(:,:,:,2));
% W(:,:,3)=W1.*contrast(I(:,:,:,3)).*saturation(I(:,:,:,3)).*well_exposedness(I(:,:,:,3));

%normalize weights: make sure that weights sum to one for each pixel
W1 = W1 + 1e-12;
W1 = W1 ./ repmat( sum(W1,3),   [1 1 N]  );
W=W1;

W(:,:,1)=makerw.w11(  I(:,:,:,1)  ).*W1(:,:,1);
W(:,:,2)=W1(:,:,2);
W(:,:,3)=W1(:,:,3);
% 
W = W + 1e-12;
W = W./repmat(sum(W,3),[1 1 N]);



if method==1 %%%Gaussian pyramid [paper 1]
    pyr = gaussian_pyramid(zeros(r,c,3),nlev);% an nlevel empty pyramid;
    for i = 1:N
        pyrW  = gaussian_pyramid( W(:,:,i),  nlev   );  %the gaussian_pyramid decomposition of weight map 
        pyrI    = laplacian_pyramid(  I1(:,:,:,i), nlev  );   %the gaussian_pyramid decomposition of input image
        for l = 1:nlev
            w = repmat( pyrW{l},[1 1 3] );
            pyr{l} = pyr{l} + w.*pyrI{l};        %same weighting of different channel of color?; 
        end
    end
    R = reconstruct_laplacian_pyramid(pyr);
elseif method==2 %%%GGIF pyramid ICME
    Y = 0.299*I1(:,:,1,:)+0.587*I1(:,:,2,:)+0.114*I1(:,:,3,:);
    pyr = gaussian_pyramid(zeros(r,c,3),nlev);
        
%     for i = 1:N
%         tmp =  Y(:,:,i);
%         W(:,:,i) = W(:,:,i)*(mean(tmp(:))^2);
%     end
%     W = W./repmat(sum(W,3),[1 1 N]);

    wsum = cell(nlev,1);
    for i = 1:N
        pyrW = gaussian_pyramid(  W(:,:,i),     nlev);
        pyrY  = gaussian_pyramid(    Y(:,:,i),     nlev);
        pyrI   = laplacian_pyramid( I1(:,:,:,i),     nlev);
        
        % all the layer of weights map used GIF guided by pyrI
        for l = 1:nlev
              %pyrW{l}=guidedfilter_WMSE_FixedRadius(pyrY{l}, pyrW{l}, radius, eps);
              pyrW{l}=gguidedfilter( pyrY{l},    pyrW{l},   radius,   eps );
        end

        for l = 1:nlev
            % accumulate the weights map over different images 
            if i == 1 
                wsum{l}= pyrW{l}+ 1e-12;
            else
                wsum{l} = wsum{l}+pyrW{l}+1e-12;
            end
            % calc fuse pyramid
            w = repmat( pyrW{l} + 1e-12,[1 1 3] );
            pyr{l} = pyr{l} + w.*pyrI{l};
        end
    end
    % normalize fuse pyramid
    for l = 1:nlev
        pyr{l} = pyr{l}./repmat(wsum{l},[1,1,3]);
    end
    % reconstruct
    R = reconstruct_laplacian_pyramid(pyr);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% contrast measure
function C = contrast(I)
h = [0 1 0; 1 -4 1; 0 1 0]; % laplacian filter
N = size(I,4);
C = zeros(size(I,1),size(I,2),N);
for i = 1:N
    mono = rgb2gray(I(:,:,:,i));
    C(:,:,i) = abs(imfilter(mono,h,'replicate'));
end

% saturation measure
function C = saturation(I)
N = size(I,4);
C = zeros(size(I,1),size(I,2),N);
for i = 1:N
    % saturation is computed as the standard deviation of the color channels
    R = I(:,:,1,i);
    G = I(:,:,2,i);
    B = I(:,:,3,i);
    mu = (R + G + B)/3;
    C(:,:,i) = sqrt(((R - mu).^2 + (G - mu).^2 + (B - mu).^2)/3);%./255;
end

% well-exposedness measure
function C = well_exposedness(I)
sig = .2; %%%only the color of final image will be effected by the value of sig.
N = size(I,4);
C = zeros(size(I,1),size(I,2),N);

for i = 1:N
    R = exp(-.4*(I(:,:,1,i) - 0.5).^2/sig.^2);
    G = exp(-.4*(I(:,:,2,i) - 0.5).^2/sig.^2);
    B = exp(-.4*(I(:,:,3,i) - 0.5).^2/sig.^2);
    C(:,:,i) = R.*G.*B;
end
