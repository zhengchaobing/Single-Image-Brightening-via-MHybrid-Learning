
    tmp_low = imread('I:\Data_Base\Data\Test\low\1.jpg');
    
     tmp=tmp_low;

    %  Y=rgb2ycbcr(tmp);
     I_1=tmp;
     tmp=double(tmp);

     %%
     %CRF
    tic;
    y1=crf(tmp,4);
    y2=crf(tmp,16);

     %imwrite(uint8(y2),'C:\Users\qjtang\Desktop\testimage\pavilionratio16.png');
    % figure,imshow(uint8(y1),[]);
    %%
    %generate
    I1=tmp;
    I2=uint8(y1);
    I3=uint8(y2);
    I2=double(I2);
    I3=double(I3);
    % figure,imshow(I2./255,[]);
    % I3=double(imread('D:\����two\test\����ͼƬ\CRF��ǿ\panda\60_16.png'));
    %%�õ�����ͼƬ����ʽ1��2��3��4��5��
    make=maker;
    % r11=make.r1(I1,I2);%��ʽ4
    % r12=make.r1(I1,I3);
    % r1=repmat(r11,[1 1 3]);
    % r2=repmat(r12,[1 1 3]);
    % 
    % low_high=r1.*I1;
    % low_midle=r2.*I1;
    % figure(1),imshow((low_high)./255,[]);
    %imwrite((low_high)./255,'F:\����two\CRF�õ��Ĳ�ͬ�ع�ͼƬ\river\r.png');
    %figure(2),imshow(low_midle,[]);
    %%WGIF����
     [I1e,I1base]=WGIF2(tmp);
     r21=make.r2(I1,I1e,I1base,I2);
    r22=make.r2(I1,I1e,I1base,I3);
     r21=repmat(r21,[1 1 3]);
    r22=repmat(r22,[1 1 3]);
    % 
    w_low_high=r21.*(I1base)+I1e;
    w_low_midle=r22.*(I1base)+I1e;

    [mtmpa,mtmpb]=change(I1);
    % r_low_high=I2.*mtmpa+low_high.*mtmpb;
    % r_low_midle=I3.*mtmpa+low_midle.*mtmpb;

    wr_low_high  = I2.*mtmpa+w_low_high.*mtmpb;

    wr_low_midle = I3.*mtmpa+w_low_midle.*mtmpb;
    wr_low_high   = uint8(wr_low_high);
    wr_low_midle  = uint8(wr_low_midle);
    figure; 
    imshow(wr_low_high,[]);
    figure; 
    imshow(wr_low_midle,[]);

    tmp_hig  =imread('I:\Data_Base\Data\Test\hig\1.jpg');
    tmp_mid = imread('I:\Data_Base\Data\Test\mid\1.jpg');
    
    wr_low_high=tmp_hig;
    wr_low_midle=tmp_mid;
    
    %fusion
    I(:,:,:,1) = tmp / 255.;
    I(:,:,:,2) = ( double( wr_low_high  ) ) / 255.;
    I(:,:,:,3) = ( double( wr_low_midle ) ) / 255.;
    method=2;
    R = exposure_fusion( I , [1 1 1] , method); %% [1,1,1] to enable the three weighting factors.