str1='H:\Experiments\Paper_3\Results_images\Result_CNN\CNN_hig\';
str2='H:\Experiments\Paper_3\Results_images\Result_CNN\CNN_mid\';
str3='H:\Experiments\Paper_3\Results_images\Result_CNN\low\';
str5='H:\Experiments\Paper_3\Results_images\Result_CNN\Result_CNN0\';
str0='.png';
str00='.png';
for ii = 1:750
    
    str4=int2str(ii);
    dirNamehig  = [str1,str4,str0];
    dirNamemid = [str2,str4,str0];
    dirNamelow = [str3,str4,str0];
    
    tmp_hig  =imread(dirNamehig);
    tmp_mid = imread(dirNamemid);
    tmp_low = imread(dirNamelow);
    
     %fusion
    I(:,:,:,1) = ( double( tmp_low ) ) / 255.;
    I(:,:,:,2) = ( double( tmp_hig  ) ) / 255.;
    I(:,:,:,3) = ( double( tmp_mid ) ) / 255.;
    method=2;
    R = exposure_fusion( I , [1 1 1] , method); 
    
    dirName5 = [str5,str4,str00];
    imwrite(R,dirName5);
    
end