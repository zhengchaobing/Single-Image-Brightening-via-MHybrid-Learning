function funs = maker2

funs.r1=@w11;

funs.r2= @w22;

end

function w=w11(mtmp)

mtmpYUV=rgb2ycbcr(mtmp);mtmpY=mtmpYUV(:,:,1);
Y=mtmpY;



Y(mtmpY>136)=4;
Y(mtmpY>=136&mtmpY<=128)=1+3.*(h(mtmpY(mtmpY>=136&mtmpY<=128))).^2.*(3-2.*h((mtmpY(mtmpY>=136&mtmpY<=128))));
Y(mtmpY<128)=(-(mtmpY(mtmpY<128)).^2)./(2.*52.*52);

w=Y;
end

function h=h(z)
h=(z-128)./8;
end

function w=w22(mtmp)
mtmpYUV=rgb2ycbcr(mtmp);mtmpY=mtmpYUV(:,:,1);
Y=mtmpY;
w=(-(Y-128).^2)./(2.*52.*52);
end


